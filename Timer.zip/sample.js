var ss = document.getElementsByClassName("timer");
[].forEach.call(ss,function(s){
    var currentTime = 0,
        interval = 0,
        lastUpdateTime = new Date().getTime(),
        start = s.querySelector('button.start'),
        stop = s.querySelector('button.stop'),
        secs = s.querySelector('span.seconds')
    start.addEventListener('click',startTimer);
    stop.addEventListener('click',stopTimer);
    function pad(n){
        return('00' + n).substr(-2);
    }
    function update(){
        var now = new Date().getTime(),
            dt = now - lastUpdateTime;
        currentTime = currentTime + dt;
        var time = new Date(currentTime);
        secs.innerHTML = pad(time.getSeconds());
        lastUpdateTime = now;
    }
    function startTimer(){
        if(!interval){
            lastUpdateTime = new Date().getTime();
            interval = setInterval(update,1);
        }
    }
    function stopTimer(){
        clearInterval(interval);
        interval = 0;
    }
});